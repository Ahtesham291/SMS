<?php
include("../DB File/connection.php");
error_reporting(0);

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	
	<style type="text/css">

		#menu{
		width: 100%;
		height: 50px;
		/*position: fixed;*/
		padding: 8px;
	}

	ul{
	list-style-type: none;
	margin: 0;
	padding: 0;
	overflow: hidden;

}

li{
	float: left;
}

li a{
	padding: 8px;
	text-decoration: none;
	background-color: #dddddd;
	color: #001;
	font-size: 22px;
	display: block;

}

li a:hover{
	color: white;
	background-color: #4caf50;
	height: 25px;
}

.active{
			background-color: #4caf50;
			color: white;

		}


	</style>
</center>
</head>
<body bgcolor="teal">

	<br><br>

	<center>
	<img src="../images/admin1.jpg"><br><h2>Welcome to Sarasvati College of Engineering</h2>
     </center>


	 <h2 style="margin-left: 25px;">Welcome Admin</h2>

<div id="menu">
	<ul>
		<li><a href="display_student_list.php">Display Student</a></li>
		<li><a href="delete.php">Delete</a></li>
		<li><a href="update.php">Update Student details</a></li>
		<li><a class="active" href="timetable.php">Add Exam Timetable</a></li>
		<li><a href="admin_timetable.php">Display Exam Timetable</a></li>
		<li style="float: right; margin-right: 100px;"><a href="../logout.php"> Logout</a></li>

		
	</ul>

</div>

	<form method="post">
		
		<center>
			
			<table border="1" cellpadding="10">

				<tr>
					<td colspan="2" align="center"><h2>Exam Time Table</h2></td>
				</tr>

				<tr>
					<td>Academic Year</td>
					<td>
						<select name="ayear" required>
							<option value="" selected="" disabled="">--select academic year--</option>
							<option value="2020-2021">2020-2021</option>
							<option value="2021-2022">2021-2022</option>
							<option value="2022-2023">2022-2023</option>
							<option value="2023-2024">2023-2024</option>
						</select>
					</td>
				</tr>
				
				<tr>
					<td>Class</td>
					<td>
						<select name="class" required>
							<option value="" selected="" disabled="">--select class--</option>
							<option value="BCA">BCA</option>
							<option value="BCOM">BCOM</option>
							<option value="MCA">MCA</option>
							<option value="BSC">BSC</option>
						</select>
					</td>
				</tr>

				<tr>
					<td>Subject</td>
					<td><input type="text" name="subject" placeholder="Enter the subject" required></td>
				</tr>

				<tr>
					<td>Time</td>
					<td><input type="text" name="etime" title="Time in ex. 2:00 PM to 5:00 PM" placeholder="Enter the time" required></td>
				</tr>

				<tr>
					<td>Date</td>
					<td><input type="date" name="edate" required></td>
				</tr>

				<tr>
					<td>Block No</td>
					<td>
						<select name="block_no" required>
							<option value="" selected="" disabled="">--select block no--</option>
							<option value="101">101</option>
							<option value="102">102</option>
							<option value="201">201</option>
							<option value="202">202</option>
						</select>
					</td>
				</tr>

				<tr>
					<td align="center" colspan="2"><input type="submit" name="submit_tt" value="Add Subject to Exam Time Table"></td>
				</tr>

			</table>

		</center>

		<br><br><br>

	</form>
	
</body>
</html>

<?php

	include("../DB File/connection.php");
	error_reporting(0);

	if(isset($_POST['submit_tt']))
	{
		$ayear=$_POST['ayear'];
		$class=$_POST['class'];
		$subject=$_POST['subject'];
		$etime=$_POST['etime'];
		$edate=$_POST['edate'];
		$block_no=$_POST['block_no'];

		 $query = mysqli_query($con,"INSERT INTO exam_tt VALUES('','$ayear','$class','$subject','$etime','$edate','$block_no')");
	    
	      if($query)
	      {
		 	echo "<center>Exam Time Table added successfully</center>";
	        header('refresh:1,url=timetable.php');

	       }
	       else
	       {
	       	echo "<center>Failed to add exam timetable</center>";
	        header('refresh:1,url=timetable.php');
	       }

	

	}

?>