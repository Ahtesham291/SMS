<?php
include("../DB File/connection.php");
error_reporting(0);
$query = "SELECT *FROM STUDENT";
$data = mysqli_query($con,$query);
$total = mysqli_num_rows($data);




if($total !=0)
{
  ?>
    <style type="text/css">

    body{
      width: 100%;
      height: 100%;
      margin: 0;
      top: 0;
    }

    #menu{
    width: 100%;
    height: 50px;
    /*position: fixed;*/
    padding: 8px;
  }

  ul{
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;

}

li{
  float: left;
}

li a{
  padding: 8px;
  text-decoration: none;
  background-color: #dddddd;
  color: #001;
  font-size: 22px;
  display: block;

}

li a:hover{
  color: white;
  background-color: #4caf50;
  height: 25px;
}

.active{
      background-color: #4caf50;
      color: white;

    }


  </style>

  </head>


  <body bgcolor="teal">

  <br><br>

  <center>
  <img src="../images/admin1.jpg"><br><h2>Welcome to Sarasvati College of Engineering</h2>
     </center>


   <h2 style="margin-left: 25px;">Welcome Admin</h2>

<div id="menu">
  <ul>
    <li><a href="display_student_list.php">Display Student</a></li>
    <li><a href="delete.php">Delete</a></li>
    <li><a class="active"  href="update.php">Update Student details</a></li>
    <li><a href="timetable.php">Add Exam Timetable</a></li>
    <li><a href="admin_timetable.php">Display Exam Timetable</a></li>
    <li style="float: right; margin-right: 100px;"><a href="../logout.php"> Logout</a></li>

    
  </ul>

</div>

<center>
  <body bgcolor="orange">
   <table bgcolor="teal" border="1" cellpadding="10">
    <tr>
      <th>Roll NO</th>
      <th>IMAGE</th>
      <th>NAME</th>
      <th>CLASS</th>
      <th>PCONT</th>
      <th>EMAIL</th>

      <th colspan="2">OPERATIONS</th>
      
    </tr>

   </center>


  <?php
  while($result = mysqli_fetch_assoc($data))



  {

  
        echo "<tr>
      <td>".$result['rollno']."</td>
      <td><a href='../$result[picsource]'><img src='../".$result['picsource']."' height='100' width='100' /></a></td>
      <td>".$result['name']."</td>
      <td>".$result['class']."</td>
      <td>".$result['pcont']."</td>
      <td>".$result['email']."</td>
     <td><a style='color:black' href='update_request_page.php?rn=$result[rollno]&n=$result[name]&cl=$result[class]&pcn=$result[pcont]&email=$result[email]'>Update</a></td>
           
     
          
        </tr>";
   

     
  }

}
 

?>

</table>

<br><br>

</body>
