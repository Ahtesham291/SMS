<?php
include("../DB File/connection.php");
error_reporting(0);

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	
	<style type="text/css">

		#menu{
		width: 100%;
		height: 50px;
		position: fixed;
		padding: 8px;
	}

	ul{
	list-style-type: none;
	margin: 0;
	padding: 0;
	overflow: hidden;

}

li{
	float: left;
}

li a{
	padding: 8px;
	text-decoration: none;
	background-color: #dddddd;
	color: #001;
	font-size: 22px;
	display: block;

}

li a:hover{
	color: white;
	background-color: #4caf50;
	height: 25px;
}

/*.active{
			background-color: #4caf50;
			color: white;

		}
*/

	</style>
</center>
</head>
<body bgcolor="teal">

	<br><br>

	<center>
	<img src="../images/admin1.jpg"><br><h2>Welcome to Sarasvati College of Engineering</h2>
     </center>


	 <h2 style="margin-left: 25px;">Welcome Admin</h2>

<div id="menu">
	<ul>
		<li><a class="active" href="display_student_list.php">Display Student</a></li>
		<li><a href="delete.php">Delete</a></li>
		<li><a href="update.php">Update Student details</a></li>
		<li><a href="timetable.php">Add Exam Timetable</a></li>
		<li><a href="admin_timetable.php">Display Exam Timetable</a></li>
		<li style="float: right; margin-right: 100px;"><a href="../logout.php"> Logout</a></li>

		
	</ul>

</div>
  
</body>
</html>