<?php
session_start();
include("DB FIle/connection.php");

?>
<center><br>
    <center><img src="images/scoelogo.jpg" height="150px"></center><br>

<body bgcolor="orange">	
<form action="" method="post" style="background-color: orange; width: 40%; height: 50%;">
    <br><br>
    <h1>Student Management System</h1><br>
Username <input type="text" name="username" value=""/><br><br>	
Password <input type="password" name="password" value=""/><br><br>
<input type="submit" name="submit" value="Login"/><br><br>
<a href='Forgot Account/check_account.php' >Forget Account ?</a><br><br>


<a href='register.php' style="color: black; text-decoration: none;">Click here to Register</a>

</form>
</center>
</body>
<?php
if(isset($_POST['submit']))
{

	$user = $_POST['username'];
	$pwd =  md5($_POST['password']);
    $query = "SELECT *FROM STUDENT WHERE username='$user' && password='$pwd'";
    $data = mysqli_query($con,$query);
    $total = mysqli_num_rows($data);
    if($total==1)
    {
    	$_SESSION['username'] =$user;
        echo "<center>Student Login Successfully</center>";
    	header('refresh:1,url=Student Login/student_home.php');
    }
    else if($user=='admin' && md5($pwd=='admin123'))
    {
        echo "<center>Admin Login Successfully</center>";
        header('refresh:1,url=Admin Login/admin_home.php');
    }
    else
   {
        echo "<center>Incorrect username or password</center>";
        header('refresh:1,url=index.php');

   }

}


?>