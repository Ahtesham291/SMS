-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2020 at 07:04 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `exam_tt`
--

CREATE TABLE `exam_tt` (
  `e_tt_id` int(11) NOT NULL,
  `ayear` varchar(50) NOT NULL,
  `class` varchar(20) NOT NULL,
  `subject` varchar(20) NOT NULL,
  `time` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `block` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exam_tt`
--

INSERT INTO `exam_tt` (`e_tt_id`, `ayear`, `class`, `subject`, `time`, `date`, `block`) VALUES
(1, '2020-2021', 'BCA', 'Software Engineering', '2:00 PM TO 5:00 PM', '2020-06-22', 101),
(2, '2020-2021', 'BCA', 'Web Developer', '2:00 PM TO 5:00 PM', '2020-06-24', 101),
(3, '2020-2021', 'BCA', 'Android Application', '2:00 PM TO 5:00 PM', '2020-06-27', 101),
(4, '2020-2021', 'BCOM', 'Finance', '10:00 AM TO 12:00 PM', '2020-06-23', 102),
(5, '2020-2021', 'BCOM', 'Banking', '10:00 AM TO 12:00 PM', '2020-06-25', 102),
(6, '2020-2021', 'BCOM', 'Management', '10:00 AM TO 12:00 PM', '2020-06-29', 102),
(7, '2020-2021', 'MCA', 'Python', '2:00 PM TO 5:00 PM', '2020-06-16', 201),
(8, '2020-2021', 'MCA', 'Ruby', '2:00 PM TO 5:00 PM', '2020-06-20', 201),
(9, '2020-2021', 'MCA', 'Machine Learning', '2:00 PM TO 5:00 PM', '2020-07-24', 201),
(10, '2020-2021', 'BSC', 'Data Structure', '2:00 PM TO 5:00 PM', '2020-07-02', 202),
(11, '2020-2021', 'BSC', 'M3', '2:00 PM TO 5:00 PM', '2020-07-04', 202),
(12, '2020-2021', 'BSC', 'C++', '2:00 PM TO 5:00 PM', '2020-07-06', 202);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `rollno` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `class` varchar(20) NOT NULL,
  `pcont` varchar(50) NOT NULL,
  `picsource` varchar(350) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(400) NOT NULL,
  `email` varchar(200) NOT NULL,
  `sec_q` varchar(200) NOT NULL,
  `sec_a` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `rollno`, `name`, `class`, `pcont`, `picsource`, `username`, `password`, `email`, `sec_q`, `sec_a`) VALUES
(1, 101, 'Ahtesham Syed', 'BCA', '9854124585', 'student/IMG_20200129_222025.jpg', 'ahtesham', 'f76e50ec089254a71b4390528139a727', 'ahteshamsyed71@gmail.com', 'What is your pet name?', 'Charlie-Ruby'),
(2, 102, 'shoheb Kazi', 'BCA', '9545874512', 'student/Capture2.PNG', 'shoheb', 'b3f6dbdd1611c5384825c21ff9476b72', 'shohebkazi456@gmail.com', 'What is your secondary email id?', 'shoheb123@gmail.com'),
(3, 103, 'Ritik Sharma', 'BCOM', '9545785245', 'student/Capture1.PNG', 'ritik', 'e6450a21cef5e3a1b0aa3681fe4eae6f', 'ritik456@gmail.com', 'What is the name of the town where you were born?', 'Wadala-106'),
(4, 104, 'Rohan Desia', 'MCA', '9545781252', 'student/Capture2.PNG', 'rohan', 'aeae5b2f900e84d784a0f0111e650835', 'rohandesia45@gmail.com', 'Where was your best family vacation as a kid?', 'UAE-Dubai-Sharjah'),
(5, 105, 'David Valvi', 'BCOM', '9847424585', 'student/download (1).jpg', 'david', '55fc5b709962876903785fd64a6961e5', 'davidvalve95@gmail.com', 'What is your secondary email id?', 'david12@gmail.com'),
(6, 106, 'Shoheb Shaikh', 'BSC', '9545784512', 'student/download (2).jpg', 'shohebs', '5d964bd1ad48beac535beae97dcfc68d', 'shoheb95@gmail.com\r\n', 'What is your pet name?', 'Monty-Ramu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exam_tt`
--
ALTER TABLE `exam_tt`
  ADD PRIMARY KEY (`e_tt_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exam_tt`
--
ALTER TABLE `exam_tt`
  MODIFY `e_tt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
