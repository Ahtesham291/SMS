<?php
  
  include("../DB FIle/connection.php");
  session_start();
  error_reporting(0);
  $userprofile = $_SESSION['username'];

   
  
  $query=mysqli_query($con,"select *from student where username='$userprofile'");
  $res =mysqli_fetch_array($query);
  $userprofile=$res['name'];

    

?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">

    body{
      margin: 0;
      padding: 0;
      top: 0;
    }
    
    a{
      
      text-decoration: none;
      font-size: 20px;
      color: white;

    }
/*
    a:hover{
      background-color: teal;
      color: white;

      
    }*/

    #maindiv{
      background-color: teal;
      width: 100%;
      /*padding: 15px;*/
      height: 35px;
    }

    div a{
      text-align: center;
      padding: 15px 16px;
      font-size: 23px;
    }

  </style>
	<title></title>


</head>
<body bgcolor="orange">

	 <br>
   <center><img src="../images/scoelogo.jpg" height="150px"></center><br>
   

   <h2 style="margin-left: 25px;">Welcome <?php echo $userprofile; ?></h2>

<div id="maindiv">

  <a href="student_home.php">Home</a>

  <a href="profile.php">Profile</a>

  <a href="about_us.php">About us</a>
  
  <a href="contact_us.php">Contact us</a>
  
  <a href="account.php">Account</a>

  <a href="student_timetable.php">Exam Time Table</a>
  
  <a href="../logout.php" style="margin-left: 390px;">Logout</a>
     
</div>

<br><br><br>

<header style="margin-left: 40px">


<h2>Location:</h2>

Kharghar, Navi Mumbai,<br>
Pin - 410210<br>
Phone - +91 9274008832<br>
Email - info@saraswaticlg.com

<center>
  
  <iframe src="https://www.youtube.com/embed/jNykR9xjlJQ" height="400" width="700" style="margin-top: -150px;"></iframe>

  <br><br>

</center>

</header>
	

</body>
</html>