<?php
  
  include("../DB FIle/connection.php");
  session_start();
  error_reporting(0);
  $userprofile = $_SESSION['username'];


  
	$query=mysqli_query($con,"select *from student where username='$userprofile'");
    $res =mysqli_fetch_array($query);
    $userprofile=$res['name'];

			

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	
	<style type="text/css">

		body{
			margin: 0;
			padding: 0;
		}
		
		a{
			
			text-decoration: none;
			font-size: 20px;
			color: white;

		}

		/*a:hover{
			background-color: teal;
			color: white;

			
		}*/

		#maindiv{
			background-color: teal;
			width: 100%;
			height: 35px;
			/*padding: 15px;*/
		}

		div a{
			text-align: center;
			padding: 15px 16px;
			font-size: 23px;
		}

	</style>
</head>
<body bgcolor="orange">
	<br>
	 <center><img src="../images/scoelogo.jpg" height="150px"></center><br>

	 <h2 style="margin-left: 25px;">Welcome <?php echo $userprofile; ?></h2>

<div id="maindiv">

	<a href="student_home.php">Home</a>

	<a href="profile.php">Profile</a>

	<a href="about_us.php">About us</a>
	
	<a href="contact_us.php">Contact us</a>
	
	<a href="account.php">Account</a>

  	<a href="student_timetable.php">Exam Time Table</a>

	<a href="../logout.php" style="margin-left: 390px;">Logout</a>
     
</div>

<header style="margin-left: 40px">
		<h3><center>Welcome to the Saraswati College Of Engineering</center></h3>
   <p>
	              Saraswati College of Engineering (SCOE) is a premier Engineering institution,
established for the purpose of imparting state of art technical education to newly
aspired engineers of the 21st Century. <br>Saraswati college of Engineering is an ISO
9001- 2008 certified Institute, a quality driven institute, striving hard for
sustainable QMS. SCOE plans to be a leading research organization with a vision<br>
of creating a knowledgeable society. The foundation of Saraswati College of
Engineering was laid on 17th September 2004. </p>
 			<img src="../images/download.jpg" width="410" >
			<img src="../images/download 1.jpg" width="435">
			<img src="../images/s1.jpg" width="405"  align="">

	</header>
</body>
</html>