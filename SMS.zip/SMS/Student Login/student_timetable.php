<?php
  
  include("../DB FIle/connection.php");
  session_start();
  error_reporting(0);
  $userprofile = $_SESSION['username'];

   
   $query=mysqli_query($con,"select *from student where username='$userprofile'");
   $res =mysqli_fetch_array($query);
   $userprofile=$res['name'];

   $class=$res['class'];
    

?>
<html>
<head>
	<style type="text/css">

    body{
      margin: 0;
      padding: 0;
    }
    
    a{
      
      text-decoration: none;
      font-size: 20px;
      color: white;

    }

   /* a:hover{
      background-color: teal;
      color: white;

      
    }*/

    #maindiv{
      background-color: teal;
      width: 100%;
      /*padding: 15px;*/
      /*top: 0;*/
      height: 35px;
      /*padding: 15px;*/

    }

    div a{
      text-align: center;
      padding: 15px 16px;
      font-size: 23px;

    }

  </style>
</head>
<body bgcolor="orange">
  <br>
   <center><img src="../images/scoelogo.jpg" height="150px"></center><br>

   <h2 style="margin-left: 25px;">Welcome <?php echo $userprofile; ?></h2>


<div id="maindiv">

  <a href="student_home.php">Home</a>

  <a href="profile.php">Profile</a>

  <a href="about_us.php">About us</a>
  
  <a href="contact_us.php">Contact us</a>
  
  <a href="account.php">Account</a>

  <a href="student_timetable.php">Exam Time Table</a>

  <a href="../logout.php" style="margin-left: 390px;">Logout</a>
  
</div>

<br><br><br>

<?php


    $qry=mysqli_query($con,"select * from exam_tt where class='$class'");

    echo "<center><table border='1' cellpadding='10'>";

    echo "<tr><td align='center' colspan='7'><h2>Exam Time table</h2></td></tr>";

    echo "<tr><th>Sr.no</th><th>Academic year</th><th>Class</th><th>Subject</th><th>Time</th><th>Date</th><th>Block</th></tr>";

    $i=1;

    while($row=mysqli_fetch_array($qry))
    {
    
        echo "<tr>
            <td>".$i."</td>
            <td>".$row['ayear']."</td>
            <td>".$row['class']."</td>
            <td>".$row['subject']."</td>
            <td>".$row['time']."</td>
            <td>".$row['date']."</td>
            <td>".$row['block']."</td></tr>"; 

            $i++;

    }

    echo "</table></center><br><br>";


?>


</body>
</html>
